#ifndef __USER_CONFIG_H__
#define __USER_CONFIG_H__

#define AT_CUSTOM_UPGRADE

#endif
